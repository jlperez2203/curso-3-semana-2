# coursera-curso-3-semana-2

![alt text](https://github.com/camiloAguado94/coursera-curso-3-semana-2/blob/master/Pantallazos/Screenshot_20191224_193213_com.camilo.formulario.jpg)

![alt text](https://github.com/camiloAguado94/coursera-curso-3-semana-2/blob/master/Pantallazos/Screenshot_20191224_193236_com.camilo.formulario.jpg)

![alt text](https://github.com/camiloAguado94/coursera-curso-3-semana-2/blob/master/Pantallazos/Screenshot_20191224_193310_com.camilo.formulario.jpg)

![alt text](https://github.com/camiloAguado94/coursera-curso-3-semana-2/blob/master/Pantallazos/Screenshot_20191224_193315_com.camilo.formulario.jpg)

![alt text](https://github.com/camiloAguado94/coursera-curso-3-semana-2/blob/master/Pantallazos/Screenshot_20191224_193320_com.camilo.formulario.jpg)
